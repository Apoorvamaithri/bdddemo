package AddNumbers;



import static org.testng.Assert.assertEquals;

import com.cg.calci.Calculator;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class StepDefN {
	Calculator calc;
	int res;
	
	@Given("^user creates object of calculator$")
	public void user_creates_object_of_calculator() throws Throwable {
	    calc = new Calculator();   
	}
	@When("^user pass (\\d+) and (\\d+) as input also (\\d+) as expected$")
	public void user_pass_and_as_input_also_as_expected(int num1, int num2, int arg3) throws Throwable {
	    res = calc.add(num1, num2);
	    assertEquals(res,arg3);
	}


	@Then("^displays sum of both numbers$")
	public void displays_sum_of_both_numbers() throws Throwable {
	    System.out.println("addition is:" +res);
	}
	
	@Given("^user pass '-(\\d+)' and '-(\\d+)' to add$")
	public void user_pass_and_to_add(int arg1, int arg2) throws Throwable {
	    System.out.println(arg1+" "+arg2);
	    res = calc.add(arg1, arg2);
	    assertEquals(res,0);
	}

	@Then("^it should display error message$")
	public void it_should_display_error_message() throws Throwable {
	   System.out.println("Invalid input given");
	}
}
